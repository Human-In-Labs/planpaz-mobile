package com.humanin.planpaz.service;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.humanin.planpaz.dto.PlantWateringStatusDTO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmailService {
	private final JavaMailSender mailSender;

	// Lista de frases motivacionais e reflexivas
	private final List<String> frasesMotivacionais = List.of(
			"✨ Frase do Dia: \"Seja puro e transparente como a água corrente. O sol brilha para todos, mas a sombra é só para quem merece!\" 🌊☀️🌳\n\n",
			"✨ Frase do Dia: \"Seja a mudança que você quer ver no mundo.\" 🌍✨\n\n",
			"✨ Frase do Dia: \"Nenhum de nós jamais faz grandes coisas sozinho. Mas todos podemos fazer pequenas coisas com grande amor, e juntos podemos fazer algo maravilhoso!\" 🤝💖🌱\n\n",

			"✨ Frase do Dia: \"Quem não sabe cuidar da raiz, não merece colher os frutos nem se abrigar na sombra.\" 🌳🍎\n\n",
			"✨ Frase do Dia: \"A tempestade que assusta o fraco é a mesma água que fortalece quem tem raiz profunda.\" 🌧️⚡💪\n\n",
			"✨ Frase do Dia: \"O tempo não apressa a semente, e a terra não cobra o tempo. Respeite o seu próprio processo.\" ⏳🌱✨\n\n",
			"✨ Frase do Dia: \"Não adiantar regar o vaso se o solo não absorve. Cuide  do coração antes de exigir frutos.\" 🫀💧🪴\n\n",
			"✨ Frase do Dia: \"A flor não compete com a do lado, ela simplesmente floresce. Seja você mesmo.\" 🌸🌿\n\n",

			"✨ Frase do Dia: \"Cultivar uma planta é cultivar a esperança de um amanhã mais verde!\" 🌸\n\n",
			"✨ Frase do Dia: \"Pequenos gestos de cuidado diário geram grandes floradas no futuro.\" 🌿\n\n",
			"✨ Frase do Dia: \"A paciência é a chave para ver suas sementes transformarem-se em vida!\" 🌻\n\n",
			"✨ Frase do Dia: \"Assim como as plantas, nós também precisamos de tempo, sol e afeto para florescer.\" ☀️\n\n",
			"✨ Frase do Dia: \"Regar suas plantas é também um momento para desacelerar e cultivar a paz interior.\" 🧘‍♀️🌱\n\n",
			"✨ Frase do Dia: \"Cada folha nova é uma vitória da sua dedicação!\" 🍃🎉\n\n",
			"✨ Frase do Dia: \"O amor e a atenção que você dedica hoje voltam em forma de natureza viva.\" 💚🌷\n\n");

	//Sorteia uma frase aleatória da lista.
	 
	private String obterFraseAleatoria() {
		int index = ThreadLocalRandom.current().nextInt(frasesMotivacionais.size());
		return frasesMotivacionais.get(index);
	}

	public void enviarAlertaRega(String para, String nomePlanta, String statusRega) {

		String fraseDoDia = obterFraseAleatoria();
		SimpleMailMessage message = new SimpleMailMessage();

		message.setTo(para);
		message.setSubject("🌱 PlanPaz | Sua planta precisa de você!");

		message.setText("Olá! 🌿\n\n" +

				"Sua plantinha \"" + nomePlanta + "\" está precisando de um pouco de atenção. 💚\n\n" +

				"💧 Status da rega: " + statusRega + "\n\n" +

				"Que tal reservar alguns minutinhos para cuidar dela? "
				+ "Pequenos cuidados fazem toda a diferença para que ela continue crescendo forte e saudável. 🌱✨\n\n" +

				fraseDoDia +

				"O PlanPaz está aqui para ajudar você nessa jornada! 💚\n\n" +

				"Até logo! 🌱\n" + "Equipe PlanPaz");

		mailSender.send(message);
	}

	// ======================================
	// E-MAIL DE VERIFICAÇÃO DE CADASTRO
	// ======================================

	public void enviarEmailDeVerificacao(String para, String nomeUsuario, String linkDeVerificacao) {
		SimpleMailMessage message = new SimpleMailMessage();

		message.setTo(para);
		message.setSubject("🌱 PlanPaz | Confirme seu e-mail");

		message.setText("Olá, " + nomeUsuario + "! 🌿\n\n" +

				"Falta só um passo para começar a cultivar seu jardim no PlanPaz.\n\n" +

				"Clique no link abaixo para confirmar seu e-mail e ativar sua conta:\n\n" +

				linkDeVerificacao + "\n\n" +

				"Esse link expira em 24 horas. Se você não fez esse cadastro, pode ignorar este e-mail.\n\n" +

				"Até logo! 🌱\n" + "Equipe PlanPaz");

		mailSender.send(message);
	}

	// ======================================
	// E-MAIL DE RESUMO DIÁRIO (ENVIADO TODOS OS DIAS ÀS 9H)
	// ======================================

	public void enviarResumoDiario(String para, String nomeUsuario, List<PlantWateringStatusDTO> plantas) {
		String fraseDoDia = obterFraseAleatoria();

		StringBuilder corpo = new StringBuilder();
		corpo.append("Bom dia, ").append(nomeUsuario).append("! 🌞\n\n");
		corpo.append("Aqui está o resumo do seu jardim hoje:\n\n");

		for (PlantWateringStatusDTO planta : plantas) {
			corpo.append(formatarStatusRega(planta.status())).append(" ").append(planta.nickname()).append("\n");
		}

		corpo.append("\n");
		corpo.append(fraseDoDia);

		corpo.append("O PlanPaz está aqui para ajudar você nessa jornada! 💚\n\n");
		corpo.append("Até logo! 🌱\n").append("Equipe PlanPaz");

		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(para);
		message.setSubject("🌱 PlanPaz | Resumo do seu jardim de hoje");
		message.setText(corpo.toString());

		mailSender.send(message);
	}

	// ======================================
	// E-MAIL DE DENÚNCIA / MODERAÇÃO (RF14)
	// ======================================

	public void enviarEmailDeDenuncia(
			String paraEquipe,
			String contentType,
			String contentId,
			String authorUsername,
			String reporterUsername,
			String reason,
			String mensagemJustificativa,
			String conteudoDenunciado
	) {
		SimpleMailMessage message = new SimpleMailMessage();

		String destino = (paraEquipe != null && !paraEquipe.isBlank()) ? paraEquipe : "moderacao@planpaz.com";
		message.setTo(destino);
		message.setSubject("🚨 [MODERAÇÃO PLANPAZ] Nova Denúncia de Conteúdo (" + contentType + ")");

		StringBuilder body = new StringBuilder();
		body.append("🚨 NOTIFICAÇÃO DE DENÚNCIA DE CONTEÚDO 🚨\n\n");
		body.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
		body.append("📌 Tipo de Conteúdo: ").append(contentType).append("\n");
		body.append("🆔 ID do Conteúdo Denunciado: ").append(contentId).append("\n");
		body.append("👤 Autor do Conteúdo: @").append(authorUsername != null ? authorUsername.replace("@", "") : "Desconhecido").append("\n");
		body.append("🕵️ Usuário Denunciante: @").append(reporterUsername != null ? reporterUsername.replace("@", "") : "Anônimo").append("\n");
		body.append("⚠️ Tipo / Motivo da Denúncia: ").append(reason).append("\n");
		if (mensagemJustificativa != null && !mensagemJustificativa.isBlank()) {
			body.append("💬 Mensagem / Justificativa: ").append(mensagemJustificativa).append("\n");
		}
		body.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n");
		body.append("📝 TEXTO DO CONTEÚDO DENUNCIADO:\n");
		body.append("\"").append(conteudoDenunciado != null ? conteudoDenunciado : "(Sem texto / imagem)").append("\"\n\n");
		body.append("Por favor, acesse o painel de moderação para analisar e tomar as providências necessárias.\n\n");
		body.append("Atenciosamente,\nSistema de Moderação PlanPaz");

		message.setText(body.toString());

		try {
			mailSender.send(message);
		} catch (Exception e) {
			System.err.println("[EMAIL MODERACAO] Erro ao enviar e-mail de denúncia: " + e.getMessage());
		}
	}

	private String formatarStatusRega(String status) {
		if (status == null) {
			return "🌿 Em dia -";
		}
		return switch (status) {
			case "atrasado" -> "🔴 Atrasada -";
			case "hoje" -> "💧 Regar hoje -";
			default -> "🌿 Em dia -";
		};
	}
}